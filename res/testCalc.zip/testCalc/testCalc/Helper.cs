﻿
namespace testCalc
{
    public static class Helper
    {
        //Helper для string. Является ли строка числом
        public static bool IsDigit(this string value)
        {
            double d;
            return double.TryParse(value, out d);
        }
    }
}
