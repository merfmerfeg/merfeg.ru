﻿using System;

namespace testCalc
{
    //Класс калькулятора, бизнес логика калькулятора
    public class Calculator
    {
        ICalculatorGui Gui { get; set; }
        ICalculatorType Type { get; set; }
        ICalculatorExprValid ExprValid { get; set; }

        public Calculator(ICalculatorGui gui, ICalculatorType type, ICalculatorExprValid exprValid)
        {
            Gui = gui;
            Type = type;
            ExprValid = exprValid;
        }
        public void Start()
        {
            //Вызываем начальный интерфейс для пользователя
            Gui.ShowUserGui();
            //Получаем данные от пользователя
            GetUserData();
        }

        private void GetUserData()
        {
            //Ожидаем ввод данных от пользователя
            string expr = Gui.UserInputData();

            //Если пользователь ввел exit завершаем работу.
            if (expr.ToLower() == "exit")
                Environment.Exit(0);

            //Валидация введенного пользователем выражения
            if (ExprValid.ExprIsValid(expr))
            {
                //Валидация пройдена успешно, вычисляем выражение и выводим результат пользователю
                Gui.ShowMessage($"Результат вычисления: {Type.Calculate(expr)}");
            }
            else
            {
                //Валидация не пройдена
                Gui.ShowMessage("Ошибка в выражении!");
            }

            //Снова ожидаем ввода данных от пользователя
            GetUserData();
        }
    }
}
