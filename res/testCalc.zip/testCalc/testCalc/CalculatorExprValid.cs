﻿using System.Text.RegularExpressions;

namespace testCalc
{
    public interface ICalculatorExprValid
    {
        bool ExprIsValid(string expression);
    }

    //Валидация введенных данных
    public class Validator : ICalculatorExprValid
    {
        public bool ExprIsValid(string expression)
        {
            //Допускаются любые символы кроме букв
            Regex regex = new Regex(@"[a-z, а-я]");

            return !regex.IsMatch(expression);
        }
    }



}
