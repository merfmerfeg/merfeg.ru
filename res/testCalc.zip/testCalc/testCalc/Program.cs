﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace testCalc
{
    class Program
    {
        static void Main(string[] args)
        {
            Calculator calc = new Calculator(new ConsoleGui(), new StandartCalculate(), new Validator());
            calc.Start();
        }
    }
}
