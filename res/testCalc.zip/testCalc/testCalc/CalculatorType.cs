﻿using System;
using System.Collections.Generic;

namespace testCalc
{
    public interface ICalculatorType
    {
        string Calculate(string expression);
    }

    //Реализация типа вычисления для калькулятора. 
    public class StandartCalculate : ICalculatorType
    {
        private List<Operation> _listOp;
        public StandartCalculate()
        {
            //Установка операций которые знает калькулятор, 
            //установка их порядка расчета 1 - самый важный, рассчитывается в первую очередь
            _listOp = new List<Operation>()
            {
                new AddOperation() { Priority = 4},
                new MinusOperation() { Priority = 3},
                new DivOperation() { Priority = 2},
                new MultOperation() { Priority = 1}
            };
        }

        public string Calculate(string expression)
        {
            try
            {
                //Создаем новое выражение с установлленным порядком операций
                return new Expression(expression, _listOp).Calculate().ToString();
            }
            catch (Exception ex)
            {
                return $"Ошибка вычисления! {ex.Message}";
            }

        }
    }
}
