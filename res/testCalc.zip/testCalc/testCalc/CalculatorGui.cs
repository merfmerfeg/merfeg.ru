﻿using System;

namespace testCalc
{
    public interface ICalculatorGui
    {
        void ShowUserGui();
        void ShowMessage(string result);
        string UserInputData();
    }


    //Реализация интерфейса для пользователя - консоль
    public class ConsoleGui : ICalculatorGui
    {
        public void ShowMessage(string result)
        {
            Console.WriteLine(result);
        }

        public void ShowUserGui()
        {
            Console.WriteLine("Наберите команду exit для выхода.");
        }

        public string UserInputData()
        {
            Console.WriteLine("Введите выражение:");
            return Console.ReadLine();
        }
    }


}
