﻿using System.Collections.Generic;
using System.Linq;

namespace testCalc
{
    //Реализация объекта выражение
    public class Expression
    {
        private string _value;
        private List<Operation> _opList;
        public Expression(string expression, List<Operation> operationList)
        {
            _value = expression;
            _opList = operationList.OrderByDescending(o => o.Priority).ToList();
        }

        public double Calculate()
        {
            //Список чисел для вычисления
            List<double> digitsList = new List<double>();

            //Получаем первую операцию и удаляем ее из списка 
            Operation operation = _opList.First();
            _opList.Remove(operation);

            //Разбиваем строку на выражения 
            foreach (string substring in _value.Split(operation.SplitSymbol))
            {
                //Если это число, то добавить его в список для расчета
                //Если это не число, создаем новое выражение (для дальнейшего счета) с тем же списком операций, кроме текущей.
                digitsList.Add((substring.IsDigit() ?
                    double.Parse(substring) :
                    new Expression(substring, _opList.ToList()).Calculate()));
            }
            //Вычисляем значение выражения из списка чисел для расчета
            return operation.Calculate(digitsList);
        }
    }
}
