﻿using System.Collections.Generic;
using System.Linq;

namespace testCalc
{
    //Абстрактный класс операция
    public abstract class Operation
    {
        public int Priority { get; set; }
        public abstract char SplitSymbol { get; }
        public abstract double Calculate(List<double> digitsList);
    }

    //Реалзиация операции сложения
    public class AddOperation : Operation
    {
        public override char SplitSymbol { get { return '+'; } }
        public override double Calculate(List<double> digitsList)
        {
            return digitsList.Sum(s => s);
        }
    }

    //Реалзиация операции вычитания
    public class MinusOperation : Operation
    {
        public override char SplitSymbol { get { return '-'; } }
        public override double Calculate(List<double> digitsList)
        {
            double firstVal = digitsList.First();
            digitsList.Remove(firstVal);

            return firstVal + digitsList.Sum(s => s * -1);
        }
    }

    //Реалзиация операции умножения
    public class MultOperation : Operation
    {
        public override char SplitSymbol { get { return '*'; } }
        public override double Calculate(List<double> digitsList)
        {
            double result = 1;
            foreach (var d in digitsList)
            {
                result *= d;
            }
            return result;
        }
    }

    //Реалзиация операции деления
    public class DivOperation : Operation
    {
        public override char SplitSymbol { get { return '/'; } }
        public override double Calculate(List<double> digitsList)
        {
            double firstVal = digitsList.First();
            digitsList.Remove(firstVal);

            foreach (var d in digitsList)
            {
                firstVal /= d;
            }
            return firstVal;
        }
    }
}
